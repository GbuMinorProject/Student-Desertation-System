<?php
error_reporting(0);
require_once("Rest.inc.php");
	class API extends REST
	{
	
	   public $data = "";

		// const DB_SERVER = "localhost";
		// const DB_USER = "editsoft_dev";
		// const DB_PASSWORD = "Team@123";
		// const DB = "editsoft_barometer";

		//const DB_SERVER = "localhost";
	//	const DB_USER = "azeemkha_team";
		//const DB_PASSWORD = "Team@123";
		//const DB = "azeemkha_salesapp";
		
		 const DB_SERVER = "gubappwebservices.esy.es";
		 const DB_USER = "u465786269";
		 const DB_PASSWORD = "123456";
		 const DB = "u465786269_gbu";
		
		private $db = NULL;

	
    public function __construct(){
            parent::__construct();              // Init parent contructor
            $this->dbConnect();                 // Initiate Database connection
        }   
        /*
         *  Database connection 
        */
        private function dbConnect(){
            $this->db = mysql_connect(self::DB_SERVER,self::DB_USER,self::DB_PASSWORD);
            if($this->db)
                mysql_select_db(self::DB,$this->db);
        }   
        /*
         * Public method for access api.
         * This method dynmically call the method based on the query string
         *
         */
        public function processApi(){
            $func = strtolower(trim(str_replace("/","",$_REQUEST['rquest'])));
            if((int)method_exists($this,$func) > 0)
                $this->$func();
            else
                $this->response('',404);                // If the method not exist with in this class, response would be "Page not found".
        }
	
		private function Student_detail_retrive()
		{
			// if($this->get_request_method() != "POST")
			//{
              //  $this->response('',406);
            //}
			//$user_id=$_POST['user_id'];
		//	if(!empty($user_id))
		//	{
				$quer="select * from Student_Registration";
				$squer=mysql_query($quer);
				$row=array();
				while($data=mysql_fetch_assoc($squer))
				{
					array_push($row,$data);
				}
				
				$this->response($this->json($row),200);
				//echo $this->json($row);
			//}
		//	else
		//	{
			//	$message=array("response code"=>101,"response desc"=>"Failed","message"=>"Invalid User detail");
		//	}
		}
		private function Student_Registary()
		{
			$name=$_POST["name"];
			$roll=$_POST["roll_no"];
			$branch=$_POST["branch"];
		$quer="insert into student_registration(`Name`,`Roll_No`,`Branch`) values('$name','$roll','$branch')";
		//die();
			$query=mysql_query($quer);
			
		}
private function json($data){
            if(is_array($data)){
                return json_encode($data);
            }
        }
    }
    
    // Initiiate Library
    
    $api = new API;
    $api->processApi();
	?>